package baseDeDatos.demoMVN;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMvnApplicationTests {

	@Test
	void contextLoads() {
	}

}
