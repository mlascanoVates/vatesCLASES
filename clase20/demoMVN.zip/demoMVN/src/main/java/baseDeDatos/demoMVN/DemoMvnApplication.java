package baseDeDatos.demoMVN;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMvnApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMvnApplication.class, args);
	}

}
