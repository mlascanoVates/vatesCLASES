package proyecto1.vatesInitia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VatesInitiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
