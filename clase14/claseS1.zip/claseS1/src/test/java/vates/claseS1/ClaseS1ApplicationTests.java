package vates.claseS1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaseS1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
