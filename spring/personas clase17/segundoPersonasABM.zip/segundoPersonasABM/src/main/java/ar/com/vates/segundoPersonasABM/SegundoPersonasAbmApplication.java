package ar.com.vates.segundoPersonasABM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SegundoPersonasAbmApplication {

	public static void main(String[] args) {
		SpringApplication.run(SegundoPersonasAbmApplication.class, args);
	}

}
