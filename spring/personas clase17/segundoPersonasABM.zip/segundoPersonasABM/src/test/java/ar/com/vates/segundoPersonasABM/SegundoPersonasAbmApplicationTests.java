package ar.com.vates.segundoPersonasABM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SegundoPersonasAbmApplicationTests {

	@Test
	void contextLoads() {
	}

}
