package ar.com.vates.primerSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
