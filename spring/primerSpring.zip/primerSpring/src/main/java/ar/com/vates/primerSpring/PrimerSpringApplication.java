package ar.com.vates.primerSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimerSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimerSpringApplication.class, args);
	}

}
